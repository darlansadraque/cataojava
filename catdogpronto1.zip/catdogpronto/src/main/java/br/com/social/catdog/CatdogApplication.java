package br.com.social.catdog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatdogApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatdogApplication.class, args);
	}

}
