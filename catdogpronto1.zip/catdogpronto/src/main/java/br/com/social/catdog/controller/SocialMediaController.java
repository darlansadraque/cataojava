package br.com.social.catdog.controller;

import br.com.social.catdog.model.Post;
import br.com.social.catdog.model.User;
import br.com.social.catdog.service.PostService;
import br.com.social.catdog.service.UserService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class SocialMediaController {
    private UserService userService;
    private PostService postService;

    public SocialMediaController(UserService userService, PostService postService){
        this.userService = userService;
        this.postService = postService;
    }
    @GetMapping
    public String index() { return "redirect:/login"; }

    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String login(String username, String password, Model model, HttpSession session) {
        if (userService.authenticateUser(username, password)) {
            model.addAttribute("username", username);
            session.setAttribute("authenticatedUser", username);
            return "redirect:/posts";
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "login";
        }
    }

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
    public String register(User user) {
        userService.registerUser(user);
        return "redirect:/login";
    }

    // Parte das postagens

    @GetMapping("/posts")
    public String postListPage(Model model){
        model.addAttribute("posts", postService.postList());
        return "posts";
    }

    @GetMapping("/post")
    public String showPostCreationForm(Model model, HttpSession session) {
        String authenticatedUser = (String) session.getAttribute("authenticatedUser");

        model.addAttribute("post", new Post());
        model.addAttribute("user", userService.findUserByUsername(authenticatedUser));

        return "new-post";
    }

    @PostMapping("/post/create")
    public String createPost(@Valid Post post, BindingResult bindingResult){
        String success = "redirect:/post?error";
        if (bindingResult.hasErrors()){
            success = "new-post";
        }

        if (post != null){
            postService.savePost(post);
            success = "redirect:/posts?success";
        }
        return success;
    }
}
