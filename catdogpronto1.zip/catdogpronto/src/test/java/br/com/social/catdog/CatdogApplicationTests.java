package br.com.social.catdog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatdogApplicationTests {

	@Test
	void contextLoads() {
	}

}
